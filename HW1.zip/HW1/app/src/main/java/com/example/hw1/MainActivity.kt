package com.example.hw1

import android.annotation.SuppressLint
import android.app.TimePickerDialog
import android.os.Bundle
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.hw1.databinding.ActivityMainBinding
import com.example.hw1.databinding.DialogNewTaskBinding
import java.text.SimpleDateFormat
import java.util.Calendar


class MainActivity : AppCompatActivity(R.layout.activity_main) {
    private lateinit var binding: ActivityMainBinding
    private lateinit var bindingDialog: DialogNewTaskBinding
    private val taskList = mutableListOf<Task>()
    private lateinit var taskDialog: AlertDialog
    private lateinit var myAdapter: MyAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        bindingDialog = DialogNewTaskBinding.inflate(layoutInflater)
        setContentView(binding.root)
        // RecyclerView
        binding.recyclerView.layoutManager = LinearLayoutManager(this)
        binding.recyclerView.setHasFixedSize(true)
        myAdapter = MyAdapter(taskList)
        binding.recyclerView.adapter = myAdapter
        binding.newTaskButton.setOnClickListener {
            showNewTaskDialog()
        }

        // Applying OnClickListener to our Adapter
        myAdapter.setOnClickListener(object :
            MyAdapter.OnClickListener {
            override fun onClickEdit(position: Int, task: Task) {
                showEditTaskDialog(position, task)
            }

            override fun onClickDelete(position: Int) {
                deleteTask(position)
            }
        })

        val builder = AlertDialog.Builder(this)
        with(builder) {
            setTitle(getString(R.string.title_new_task))
            setView(bindingDialog.root)
        }
        taskDialog = builder.create()
    }

    @SuppressLint("SimpleDateFormat", "NotifyDataSetChanged")
    private fun showNewTaskDialog() {
        bindingDialog.name.text.clear()
        bindingDialog.description.text.clear()
        bindingDialog.selectTime.text = getString(R.string.button_select_time)
        taskDialog.setTitle(getString(R.string.title_new_task))
        taskDialog.show()
        bindingDialog.selectTime.setOnClickListener {
            val cal = Calendar.getInstance()
            val timeSetListener = TimePickerDialog.OnTimeSetListener { timePicker, hour, minute ->
                cal.set(Calendar.HOUR_OF_DAY, hour)
                cal.set(Calendar.MINUTE, minute)
                bindingDialog.selectTime.text = SimpleDateFormat("HH:mm").format(cal.time)
            }
            TimePickerDialog(this, timeSetListener, cal.get(Calendar.HOUR_OF_DAY), cal.get(Calendar.MINUTE), true).show()
        }
        bindingDialog.save.setOnClickListener {
            val newTask = Task(bindingDialog.name.text.toString(),
                bindingDialog.description.text.toString(),
                if (bindingDialog.selectTime.text.toString() != getString(R.string.button_select_time))
                    bindingDialog.selectTime.text.toString() else "",
                false)
            taskList.add(newTask)
            myAdapter.notifyDataSetChanged()
            taskDialog.dismiss()
        }
    }

    @SuppressLint("SimpleDateFormat", "NotifyDataSetChanged")
    private fun showEditTaskDialog(position: Int, task: Task) {
        bindingDialog.name.setText(task.name)
        bindingDialog.description.setText(task.description)
        bindingDialog.selectTime.text = if (task.deadline == "") getString(R.string.button_select_time) else task.deadline
        taskDialog.setTitle(getString(R.string.title_edit_task))
        taskDialog.show()
        bindingDialog.selectTime.setOnClickListener {
            val cal = Calendar.getInstance()
            val timeSetListener = TimePickerDialog.OnTimeSetListener { timePicker, hour, minute ->
                cal.set(Calendar.HOUR_OF_DAY, hour)
                cal.set(Calendar.MINUTE, minute)
                bindingDialog.selectTime.text = SimpleDateFormat("HH:mm").format(cal.time)
            }
            val hour = if (task.deadline == "") cal.get(Calendar.HOUR_OF_DAY) else task.deadline.split(":")[0].toInt()
            val min = if (task.deadline == "") cal.get(Calendar.MINUTE) else task.deadline.split(":")[1].toInt()
            TimePickerDialog(this, timeSetListener, hour, min, true).show()
        }
        bindingDialog.save.setOnClickListener {
            val updatedTask = Task(bindingDialog.name.text.toString(),
                bindingDialog.description.text.toString(),
                if (bindingDialog.selectTime.text.toString() != getString(R.string.button_select_time))
                    bindingDialog.selectTime.text.toString() else "",
                taskList[position].isChecked)
            taskList[position] = updatedTask
            myAdapter.notifyDataSetChanged()
            taskDialog.dismiss()
        }
    }

    @SuppressLint("NotifyDataSetChanged")
    fun deleteTask(position: Int) {
        taskList.removeAt(position)
        myAdapter.notifyDataSetChanged()
    }
}