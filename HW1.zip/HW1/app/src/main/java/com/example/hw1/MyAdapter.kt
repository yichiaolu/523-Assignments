package com.example.hw1

import android.view.LayoutInflater
import android.view.ViewGroup
import android.widget.ImageButton
import androidx.recyclerview.widget.RecyclerView
import com.example.hw1.databinding.RowRecyclerviewBinding

class MyAdapter(private val taskList: MutableList<Task>) : RecyclerView.Adapter<MyAdapter.ViewHolder>() {

    private lateinit var binding: RowRecyclerviewBinding
    private var onClickListener: OnClickListener? = null

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        binding = RowRecyclerviewBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return ViewHolder(binding)
    }

    override fun getItemCount(): Int = taskList.size

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val task = taskList[position]
        holder.bind(task)
        holder.itemView.findViewById<ImageButton>(R.id.delete).setOnClickListener {
            if (onClickListener != null) {
                onClickListener!!.onClickDelete(position)
            }
        }
        holder.itemView.setOnClickListener {
            if (onClickListener != null) {
                onClickListener!!.onClickEdit(position, task)
            }
        }
    }

    // Holds the views for adding it to image and text
    class ViewHolder (private val binding: RowRecyclerviewBinding) : RecyclerView.ViewHolder(binding.root) {
        fun bind(task: Task) {
            binding.name.text = task.name
            binding.deadline.text = task.deadline
            binding.checkbox.isChecked = task.isChecked
            binding.checkbox.setOnClickListener {
                task.isChecked = binding.checkbox.isChecked
            }
        }
    }

    // A function to bind the onclickListener.
    fun setOnClickListener(onClickListener: OnClickListener) {
        this.onClickListener = onClickListener
    }

    // onClickListener Interface
    interface OnClickListener {
        fun onClickEdit(position: Int, task: Task)
        fun onClickDelete(position: Int)
    }
}