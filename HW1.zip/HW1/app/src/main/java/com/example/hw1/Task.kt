package com.example.hw1

data class Task(
    var name: String,
    var description: String,
    var deadline: String,
    var isChecked: Boolean
)
